JiSi Play Zone — Brand Kit
==========================

FOLDERS
1-Print ................ Opening poster (A3), flex banner (6 x 3 ft), shop signboard (10 x 3 ft)
2-Pamphlet ............. A5 pamphlet, front and back
3-Tshirts .............. Staff T-shirt and party host T-shirt (front + back, with colour codes)
4-Instagram-WhatsApp ... Three square posts (1080 x 1080): opening soon, play prices, birthday parties
5-Brand-Colours ........ Colour codes (HEX, CMYK, RGB) and the full colour guide (open the .html in a browser)

WHICH FILE TO USE
- PDF  -> give to the printer / flex / signboard shop. These are vector files: text and cartoons
          stay sharp at any size, even the 10 ft signboard.
- PNG  -> for WhatsApp, Instagram, phone sharing and quick previews (high resolution, 2x).

BEFORE PRINTING OR POSTING
- Replace [OPENING DATE] (poster, pamphlet front, "Opening soon" post) and [@instagram] (pamphlet back).
  These are placeholders. Ask your designer to edit them, or ask Claude to update and re-export.
- Check prices, phone number (+91 94418 80054) and timings are still correct.
- Ask the printer for a printed proof first: colours on paper, flex and fabric look a little
  different from the screen.
- Pamphlet: print A5 (148 x 210 mm), double-sided — 04 front, 05 back.
- Flex banner and signboard: the printer scales the PDF to the full size (6 x 3 ft and 10 x 3 ft);
  the proportions already match.

Brand fonts: Baloo 2 (headings) and Nunito (text), both free from Google Fonts.
